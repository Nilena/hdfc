import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
    {
      path: 'package',
      loadChildren: () => import('./package/package.module').then(module => module.PackageModule)
    },
    {
      path: 'case',
      loadChildren: () => import('./case/case.module').then(module => module.CaseModule)
    },
    {
      path: '', redirectTo: 'package', pathMatch: 'full'
    }
    ]
  },
  {
    path: '**', redirectTo: '', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ scrollPositionRestoration: 'top' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
