import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CaseService } from '../../services/case.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { HttpErrorResponse } from '@angular/common/http';
import { UtilityService } from 'src/app/shared/Services/utility.service';
import { DocumentList, Comments, TestedPartyRoles } from 'src/app/core/Models/Interfaces/case';
import { DocumentTypes } from 'src/app/core/Models/Interfaces/package';
import { SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-document-preview',
  templateUrl: './document-preview.component.html',
  styleUrls: ['../../../../assets/style/css/case.css']
})
export class DocumentPreviewComponent implements OnInit {
  @Input() docId: number = 0;
  @Output() close : EventEmitter<boolean> = new EventEmitter<boolean>();
  public pdfSrc : SafeHtml | null= null;
  documentList! : DocumentList;
  comments      :  Comments[] = [];
  documentTypes : DocumentTypes[] = [];
  testPartyRoles: TestedPartyRoles[] = [];
  showSlider    : boolean = false;
  constructor(private caseService: CaseService,
    private loader: LoaderService,
    private alertandtoaster: AlertandtoasterService,
    private utility: UtilityService) { }

  ngOnInit(): void {
    this.loader.isContentLoader(true);
    this.getDetails();
  }
  ngAfterViewInit() {
    setTimeout(() => { this.showSlider = true; });
  }
  /*
   * @desc: to close
   * @author: Nilena Alexander
   */
  closeBtn() {
    setTimeout(() => { this.close.emit(false); }, 400);
    this.showSlider = false;
  }

  /*
   * @desc: to get details
   * @author: Nilena Alexander
   */

  getDetails() {
    this.loader.isContentLoader(true);
    this.caseService.doumentPreview(this.docId).subscribe((res) => {
      if (res && res.success) {
        this.documentList = res.data.document;
        this.comments = res.data.document.comments;
        this.documentTypes = this.documentList.documentTypes;
        this.testPartyRoles = this.documentList.testPartyRoles;
        this.pdfSrc = this.utility.fileChangeEvent(res.data.document, true);
        this.loader.isContentLoader(false);

      }
      else {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.utility.apiHttpErrorHandler(err);
      this.loader.isContentLoader(false);
    })
  }
}
