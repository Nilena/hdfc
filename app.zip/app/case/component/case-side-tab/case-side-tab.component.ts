import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-side-tab',
  templateUrl: './case-side-tab.component.html',
  styleUrls: ['./case-side-tab.component.css',
  '../../../../assets/style/css/accordion.css',
  '../../../../assets/style/css/case.css']
})
export class CaseSideTabComponent implements OnInit {

  @Input() caseId! : number;
  @Input() agencyId! : number|undefined;
  docOpen : boolean = false;
  accOpen : boolean =false;

  constructor() { }

  ngOnInit(): void {
  }

}
