import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectorNameSelectorComponent } from './collector-name-selector.component';

describe('CollectorNameSelectorComponent', () => {
  let component: CollectorNameSelectorComponent;
  let fixture: ComponentFixture<CollectorNameSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollectorNameSelectorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectorNameSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
