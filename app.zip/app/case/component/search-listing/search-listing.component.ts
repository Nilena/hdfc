import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuickSearchData } from 'src/app/core/Models/Interfaces/case';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { UtilityService } from 'src/app/shared/Services/utility.service';
import { CaseService } from '../../services/case.service';


@Component({
  selector: 'app-search-listing',
  templateUrl: './search-listing.component.html',
  styleUrls: ['../../../../assets/style/css/case.css']
})
export class SearchListingComponent implements OnInit {

  setFilterView: boolean = true;
  caseArrayList: any = [];
  quickSearchData !: QuickSearchData;
  quickSearchDataFromLS !: QuickSearchData;

  advancedSearchData: any;


  firstItem: number = 1;
  lastItem: number = 0;
  currentPage: number = 1;
  recordsPerPage: number = 10;
  totalElements !: number;
  totalPages!: number;

  constructor(
    private loaderService: LoaderService,
    private caseService: CaseService,
    private alertandtoaster: AlertandtoasterService,
    private router: Router,
    private utility: UtilityService
  ) { }

  ngOnInit(): void {
    if (localStorage.getItem('recordsPerPage2')) {
      let records = JSON.parse(localStorage.getItem('recordsPerPage2') || '{}');
      this.recordsPerPage = records;
      this.lastItem = this.recordsPerPage;
    }
    this.lastItem = this.recordsPerPage;

    if (localStorage.getItem('current_page')) {
      this.currentPage = JSON.parse(localStorage.getItem('current_page') || '{}');
    }

  }

  clearData(event: boolean) {
    this.caseArrayList = [];
  }

  navigateTo(agencynumber: string) {
    this.router.navigate(['case/details/' + agencynumber]);
  }

  quickSearchDataFromParent(data: QuickSearchData) {
    localStorage.setItem('quickSearchData', JSON.stringify(data));
    this.quickSearchData = data;
    this.currentPage = Number(localStorage.getItem('current_page'))
    this.getCaseLisitngs(this.quickSearchData, this.recordsPerPage, this.currentPage);
  }

  advacedSearchDataFromParent(data: any) {
    this.advancedSearchData = this.objectToURLParam(data);
    this.getCaseLisitngsAdvSearch(JSON.stringify(this.advancedSearchData), this.recordsPerPage, this.currentPage)
  }

  objectToURLParam(obj: any) {
    let keys: any = {};
    for (let key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (obj[key] != null) {
          keys[key] = obj[key];
        }
      }
    }
    return keys;
  }


  changeItemsPerPage(itemsPerpage: any) {
    this.currentPage = 1; // RESET BACK TO CURRENT PAGE 1
    localStorage.setItem('current_page', JSON.stringify(this.currentPage));
    this.recordsPerPage = itemsPerpage.target.value;
    this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
    if (this.lastItem > this.totalElements) {
      this.lastItem = this.totalElements;
    }
    localStorage.setItem('recordsPerPage2', JSON.stringify(this.recordsPerPage));

    if (localStorage.getItem('quickSearchData')) {
    this.getCaseLisitngs(this.quickSearchData, this.recordsPerPage, this.currentPage);
    }
    if (localStorage.getItem('advancedSearchData')){
      this.getCaseLisitngsAdvSearch(JSON.stringify(this.advancedSearchData), this.recordsPerPage, this.currentPage)
    }
  }

  selectPage(value: number) {
    this.currentPage = value;
    localStorage.setItem('current_page', JSON.stringify(this.currentPage));
    this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
    if (this.lastItem > this.totalElements) {
      this.lastItem = this.totalElements;
    }

    if (localStorage.getItem('quickSearchData')) {
      this.getCaseLisitngs(this.quickSearchData, this.recordsPerPage, this.currentPage);
    }
    if (localStorage.getItem('advancedSearchData')){
      this.getCaseLisitngsAdvSearch(JSON.stringify(this.advancedSearchData), this.recordsPerPage, this.currentPage)
    }
    
  }


  getCaseLisitngs(data: QuickSearchData, recordsPerPage: number, currentPage: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getCaseLisitngsData(currentPage, recordsPerPage, data.caseNo, data.referenceNo, data.testedParty, data.dob).subscribe(
      (response) => {
        this.caseLisitingforQuickandAdv(response);
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: err?.error?.message,
        });
      }
    );
  }


  getCaseLisitngsAdvSearch(data: any, recordsPerPage: number, currentPage: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getCaseLisitngsDataAdvancedSearch(currentPage, recordsPerPage, data).subscribe(
      (response) => {
        this.caseLisitingforQuickandAdv(response);
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }

  caseLisitingforQuickandAdv(response :any){
    if (response.success) {
      this.caseArrayList = response.data.cases;
      this.totalElements = response.data.totalElements;
      this.totalPages = response.data.totalPages;
      this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
      this.lastItem = this.recordsPerPage * this.currentPage;
      if (this.lastItem > this.totalElements) {
        this.lastItem = this.totalElements;
      }
    }
    else {
      this.caseArrayList = [];
    }

  }




}
