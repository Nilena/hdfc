import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionSiteSelectorComponent } from './collection-site-selector.component';

describe('CollectionSiteSelectorComponent', () => {
  let component: CollectionSiteSelectorComponent;
  let fixture: ComponentFixture<CollectionSiteSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollectionSiteSelectorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionSiteSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
