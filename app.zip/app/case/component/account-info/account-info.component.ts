import { Component, OnInit, Input } from '@angular/core';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { CaseService } from '../../services/case.service';

@Component({
  selector: 'app-account-info',
  templateUrl: './account-info.component.html',
  styleUrls: ['./account-info.component.css']
})
export class AccountInfoComponent implements OnInit {

  tabView:number = 0;  
  accountDetails : any;
  @Input() caseId: number = 0;
  @Input() agencyId: number |null = null;

  constructor(private caseService: CaseService,
    private loaderService: LoaderService) { }

  ngOnInit(): void {
    console.log(this.caseId);
    this.getAccountInfo();
  }

  getAccountInfo(){
    this.loaderService.isLoaderEnable(true);
    this.caseService.getDeliveryAgencyListing(this.caseId).subscribe((response) => {
      if(response.success){
        this.accountDetails = response.data.agency;
        console.log(this.accountDetails);
      }
      this.loaderService.isLoaderEnable(false);
    })

  }

}
