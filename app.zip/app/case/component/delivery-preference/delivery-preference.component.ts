import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';
import { Languages } from 'src/app/core/Models/Interfaces/case';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { CaseService } from '../../services/case.service';

@Component({
  selector: 'app-delivery-preference',
  templateUrl: './delivery-preference.component.html',
  styleUrls: ['./delivery-preference.component.css','../../../../assets/style/css/singleselect.css']
})
export class DeliveryPreferenceComponent implements OnInit {
  public deliveryPreferenceForm !: FormGroup
  tabView: boolean = true;
  addNewForm : boolean = false;
  languageList: Languages[] = [];
  constructor( private fb: FormBuilder,private loaderService: LoaderService
    ,private caseService: CaseService,private alertandtoaster: AlertandtoasterService,) { }
 
  ngOnInit(): void {
    this.createForm();
  }

  langArray: any[] = [{

      langId: 1,
      language: 'English',
    },
    {
      langId: 2,
      language: 'French',
    }]
    createForm(): void {
      this.deliveryPreferenceForm = this.fb.group({
        testedParty:[null],
        copies:[null],
        languages:[null],
        emboss:[null],
        affidavit:[null],
        delivery:[null],
        email:[null],
        courier:[null],
        name:[null,[Validators.required]],
        ass: [null],
        address: [null,[Validators.required]],
        suite: [null],
        city: [null,[Validators.required]],
        state: [null],
        zip: [null,[Validators.required]],
        country: [null],
        code: [null,[Validators.required]],
      });
    }
  changeTabView(tabView: boolean) {
    this.tabView = tabView ? true:false;
    this.addNewForm = false;
  }
  goBack(){
    history.back();
  }
  selectedTestedParty(event:any){
    this.deliveryPreferenceForm.controls?.testedParty.patchValue(event);
    console.log(event);
  }
  selectedLanguage(event:any){
    console.log(event);
  }
  addNew(){
    this.addNewForm = true;
  }
  cancel(){
    this.addNewForm = false;
  }
  // getLanguageList() {
  // ///  this.loaderService.isLoaderEnable(true);
  //   this.caseService.getLanguages().subscribe(
  //     (response) => {
  //       if (response.success) {
  //         let langlist = response;
  //         this.languageList = langlist.data.languages;
  //         console.log(this.languageList);
  //       } else {
  //         this.languageList = [];
  //         this.loaderService.isLoaderEnable(false);
  //       }
  //     },
  //     (err: HttpErrorResponse) => {
  //       this.loaderService.isLoaderEnable(false);
  //       this.alertandtoaster.alert.toast({
  //         title: 'Error',
  //         type: 'error',
  //         message: err?.error?.message,
  //       });
  //     }
  //   );
  // }
}
