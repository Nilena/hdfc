import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryPreferenceComponent } from './delivery-preference.component';

describe('DeliveryPreferenceComponent', () => {
  let component: DeliveryPreferenceComponent;
  let fixture: ComponentFixture<DeliveryPreferenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeliveryPreferenceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryPreferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
