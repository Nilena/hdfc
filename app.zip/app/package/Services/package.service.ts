import { Injectable } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/Constants/apilist';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiResponse } from 'src/app/core/Models/Interfaces/commonInterface';
import { Observable, forkJoin } from 'rxjs';
import { UserdetailsResponse, ChanneUpdateRequest,SaveTrackingItem, AddComments } from 'src/app/core/Models/Interfaces/package';
import { PackageListigRequest } from 'src/app/core/Models/class/api/request/package-listig-request';

@Injectable({
  providedIn: 'root'
})
export class PackageService {
  constructor(
    private http: HttpClient,
  ) { }

  /*
  auth: Elizabeth mathew
  desc: to get channels list
  */
  getChannelListing() {
    let endpoint = getApiUrl(apiList.package.getChannels);
     return this.http.get<ApiResponse>(endpoint);
    
  }

  /*
  auth: Nilena Alexander
  desc: to get courier agents list
  */
  getCourierList(){
    let endpoint = getApiUrl(apiList.package.getCourier);
    return this.http.get<ApiResponse>(endpoint); 
  }

  /*
  auth: Elizabeth mathew
  desc: forkjoin to get courier agents list and channel list
  */
  getChannelAndCourierData(isUserdeatils: boolean) {
    return forkJoin(
      isUserdeatils? [this.getChannelListing(), this.getCourierList(), this.getUserData()] :
      [this.getChannelListing(), this.getCourierList()]
    )
  }

   /*
  auth: Abhiram M Sajeev
  desc: get intake package data
  */
  getPackages(req: PackageListigRequest): Observable<ApiResponse> {
    let url = getApiUrl(apiList.package.packageListing);
    let params = new HttpParams();
    params = params.append('pageNo', req.pageNo);
    params = params.append('pageSize', req.pageSize);
    if(req.trckNo!== '') {
      params = params.append('trackingNumber', req.trckNo);
    }
    if(req.usr !== 0) {
      params = params.append('userId', req.usr);
    } 
    if(req.chnl !== 0) {
      params = params.append('channelId', req.chnl);
    } 
    if(req.cur !== 0) {
      params = params.append('courierId', req.cur);
    } 
    if(req.toDt !== '') {
      params = params.append('toDate', req.toDt);
    } 
    if(req.frmDt !== '') {
      params = params.append('fromDate', req.frmDt);
    } 
    if(req.sort==='asc') {
      params = params.append('sort', 'createdOn');
    }
    if(req.sort === 'desc'){
      params = params.append('sort','-createdOn');
    }
    return this.http.get(url, {params: params}) as Observable<ApiResponse>;
  }
  /*
  auth: Abhiram M Sajeev
  desc: to get details of user 
  */
  getUserData(): Observable<UserdetailsResponse> {
    let url = getApiUrl(apiList.package.getUsersdata);
    return this.http.get(url) as Observable<UserdetailsResponse>
  }

  /*
  auth: Nilena Alexander
  desc: to delete takingId Against intake
  */
 deleteTrackingItems(id:number) : Observable<ApiResponse>{
  let endpoint = getApiUrl(apiList.package.getTracking+'/'+id);
  return this.http.delete<ApiResponse>(endpoint); 
  }

  /*
  auth: Nilena Alexander
  desc: to trackingId Against intake
  */
 saveTrackingItem(payload:SaveTrackingItem) : Observable<ApiResponse>{
  let endpoint = getApiUrl(apiList.package.packageListing);
  return this.http.post<ApiResponse>(endpoint,payload); 
}

 /*
  auth: Abhiram M Sajeev
  desc: Update channel 
  */
  updateChannel(req: ChanneUpdateRequest): Observable<ApiResponse> {
    let url = getApiUrl(apiList.package.packageListing);
    return this.http.put(url, req) as Observable<ApiResponse>
  }

  /*
  auth: Nilena Alexander
  desc: to trackingId Against intake
  */
 addComments(payload:AddComments) : Observable<ApiResponse>{
  let endpoint = getApiUrl(apiList.package.getComments);
  return this.http.post<ApiResponse>(endpoint,payload); 
}

 /*
  auth: Nilena Alexander
  desc: to reset intake
  */
 deleteIntake(intakeId:number) : Observable<ApiResponse>{
  let endpoint = getApiUrl(apiList.package.packageListing)+`/${intakeId}`;
  return this.http.delete<ApiResponse>(endpoint); 
}
 /*
  auth: Nilena Alexander
  desc: to details of sign and print receipt
  */
getReceipt(intakeId:number){
  let endpoint = getApiUrl(apiList.package.getReceipt)+`/${intakeId}`;
  return this.http.get<ApiResponse>(endpoint); 
}
  /*
  auth: Abhiram M Sajeev
  desc: get internal package details
  */
  getInternalPackage(id: number): Observable<ApiResponse> {
    let endpoint = getApiUrl(apiList.package.packageListing+ `/${id}/notification`);
    return this.http.get(endpoint) as Observable<ApiResponse>;
  }
}
