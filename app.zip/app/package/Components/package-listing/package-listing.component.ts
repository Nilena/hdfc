import { Component, OnInit, Input, Renderer2 } from '@angular/core';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import {
  Channels,
  CourierAgntList,
  ChanneUpdateRequest,
  UserPayload,
  PackageResponsePayload,
  PackagesPayaload,
  ChannelsPayaload,
} from 'src/app/core/Models/Interfaces/package';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { FormGroup, FormControl } from '@angular/forms';
import { PackageService } from '../../Services/package.service';
import { HttpErrorResponse } from '@angular/common/http';
import { PackageListigRequest } from 'src/app/core/Models/class/api/request/package-listig-request';
import * as moment from 'moment';
@Component({
  selector: 'app-package-listing',
  templateUrl: './package-listing.component.html',
  styleUrls: [
    '../../../../assets/style/css/packages.css',
    '../../../../assets/style/css/pagination.css',
  ],
})
export class PackageListingComponent implements OnInit {
  @Input() backtoNotify!: boolean;
  @Input() openInternalPackage!: boolean;
  today = new Date();
  firstItem: number = 1;
  lastItem: number = 0;
  commentSliderLabel: string = '';
  commentSliderIcon: string = '';
  viewCommentsSection: boolean = false;
  ViewchannelSection: boolean = false;
  showEmailSection: boolean = false;
  showNotificationSection: boolean = false;
  showPrintScreen: boolean = false;
  intakeId!: number;
  totalLength!: number;
  showCommentSlider: boolean = false;
  showNotifyInternalPackage: boolean = false;
  comments: string = '';
  commentSliderData!: any;
  fromIntenalPackage: boolean = false;
  currentPage: number = 1;
  recordsPerPage: number = 10;
  totalElement: number = 1;
  orderOfTat: string = '';
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  filterTrackingNumber = new FormControl('');
  intakeResponse!: PackageResponsePayload;
  intakePackage: PackagesPayaload[] = [];
  channelArrayList: Channels[] = [];
  courierAgntList: CourierAgntList[] = [];
  showCommentSlider1: boolean = false;
  userDetails: UserPayload[] = [];
  filterPerson: number = 0;
  filterChannel: number = 0;
  filterCourier: number = 0;
  trackingData!: PackagesPayaload;
  startDate: string = '';
  endDate: string = '';
  isApplyfilter: boolean = false;
  index: any = '';
  sortAsc: boolean = true;
  sortDec: boolean = true;
  activeSortAsc: boolean = false;
  activeSortDes: boolean = false;
  duplicateFilter: any = {};
  expantedIntakes: PackagesPayaload[] = [];
  constructor(
    private alertandToast: AlertandtoasterService,
    private loaderService: LoaderService,
    private packageService: PackageService,
    private render: Renderer2
  ) {}

  ngOnInit(): void {
    if (localStorage.getItem('recordsPerPage')) {
      let records = JSON.parse(localStorage.getItem('recordsPerPage') || '{}');
      this.recordsPerPage = records;
      this.lastItem = this.recordsPerPage;
    }
    this.getPackageWithFilter(true);
    this.getChannelAndCourierData();
    this.lastItem = this.recordsPerPage;
  }

  /*
   * @Desc   : set pakage request with filter.
   * @Author : Abhiram M Sajeev
   * @Param  : Pass pagenumber and number of items per page.
   */
  getPackageWithFilter(refresh: boolean) {
    if (this.isApplyfilter) {
      this.getPackages(this.duplicateFilter, refresh);
    } else {
      this.duplicateFilter = {};
      const packageListigRequest = new PackageListigRequest(
        this.recordsPerPage,
        this.currentPage,
        '',
        0,
        0,
        0,
        '',
        ''
      );
      this.duplicateFilter = packageListigRequest;
      this.getPackages(this.duplicateFilter, true);
    }
  }
  /*
   * @Desc   : get all the intakes courier data.
   * @Author : Abhiram M Sajeev
   * @Param  : Pass pagenumber and number of items per page.
   */
  getPackages(req: PackageListigRequest, isRefresh?: boolean): void {
    this.loaderService.isLoaderEnable(true);
    this.expantedIntakes = [...this.intakePackage];
    this.packageService.getPackages(req).subscribe(
      (res) => {
        if (res.success) {
          this.intakeResponse = res.data;
          this.intakePackage = this.intakeResponse.packages;
          this.totalElement = res.data.totalElements;
          for (let item of this.expantedIntakes) {
            if (item.isExpandRow) {
              this.intakePackage.forEach((elemet) => {
                if (elemet.inTakeId === item.inTakeId) {
                  elemet.isExpandRow = true;
                } else {
                  elemet.isExpandRow = false;
                }
              });
            }
          }

          this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
          this.lastItem = this.recordsPerPage * this.currentPage;
          if (this.lastItem > this.totalElement) {
            this.lastItem = this.totalElement;
          }
        } else {
          this.intakePackage = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (error: HttpErrorResponse) => {
        this.intakePackage = [];
        this.loaderService.isLoaderEnable(false);
        this.apiHttpErrorHandler(error);
      }
    );
  }

  /*
   * @Desc   : get selected channel count aganist each of the intake .
   * @Author : Abhiram M Sajeev
   * @Param  : Pass channel array and channel name.
   */
  getChannelCount(channel: ChannelsPayaload[], currentChannel: Channels) {
    const countArray: ChannelsPayaload[] = channel.filter(
      (value) => +value.channelId === currentChannel.channelId
    );
    if (countArray.length > 0) {
      return countArray[0].channelCount;
    } else {
      return 0;
    }
  }

  /*
   * @Desc   : select number of items need to dispaly in a page
   * @Author : Abhiram M Sajeev
   */
  changeItemsPerPage(itemsPerpage: any) {
    this.recordsPerPage = itemsPerpage.target.value;
    this.currentPage = 1;
    this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
    this.lastItem = this.recordsPerPage * this.currentPage;
    if (this.lastItem > this.totalElement) {
      this.lastItem = this.totalElement;
    }
    localStorage.setItem('recordsPerPage', JSON.stringify(this.recordsPerPage));
    this.getPackageWithFilter(false);
  }

  /*
   * @Desc   : select which page need to display
   * @Author : Abhiram M Sajeev
   */
  selectPage(value: number) {
    this.index = null;
    this.currentPage = value;
    window.scrollTo(0, 0);
    this.firstItem = (this.currentPage - 1) * this.recordsPerPage + 1;
    this.lastItem = this.recordsPerPage * this.currentPage;
    if (this.lastItem > this.totalElement) {
      this.lastItem = this.totalElement;
    }
    const packageListigRequest = new PackageListigRequest(
      this.recordsPerPage,
      this.currentPage,
      this.filterTrackingNumber.value,
      this.filterCourier,
      this.filterChannel,
      this.filterPerson,
      this.startDate,
      this.endDate
    );
    this.duplicateFilter = packageListigRequest;
    this.getPackages(packageListigRequest, true);
  }

  /*
   * @desc: to list Courier, channels and userdetails via fork join.
   * @author: Abhiram M Sajeev
   * @params: pass a boolean value for include the user details api (if pass true include user details get api)
   */

  getChannelAndCourierData(): void {
    this.loaderService.isLoaderEnable(true);
    this.packageService.getChannelAndCourierData(true).subscribe(
      (res) => {
        if (res[0].success) {
          this.channelArrayList = res[0].data.channels;
        } else {
          this.channelArrayList = [];
        }

        if (res[1].success) {
          this.courierAgntList = res[1].data.couriers;
        } else {
          this.courierAgntList = [];
        }

        if (res[2].success) {
          this.userDetails = res[2].data.users;
        } else {
          this.userDetails = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (error: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.apiHttpErrorHandler(error);
      }
    );
  }

  /*
   * @Desc   : Sorting data according to TAT - turn around time.
               Also orderOfTat shows the CSS class as asc/desc
               Reset orderOfTat for no sort order
   * @Author : Arjun S
   * @Param  : Pass in true to sort in asc and false for desc.
   */
  sortWithTat(order: boolean, index: number) {    
    this.orderOfTat = order ?  'ascending' : 'descending';
    this.sortFnc(order,index);    
    this.orderOfTat = order ? 'ascending' : 'descending';

    let withNa: any = this.intakePackage[index].trackings.filter(
      (el: any) => el.tat === 'NA'
    );
    this.intakePackage[index].trackings = this.intakePackage[
      index
    ].trackings.filter((el: any) => el.tat !== 'NA');
    this.sortFnc(order,index);    
    withNa.map((el: any) => this.intakePackage[index].trackings.push(el));
  }

  /*
   * @Desc   : Function to sort
   * @Author : Manaf
   * @Param  : .
   */

  sortFnc(order : boolean ,index : number){
    this.intakePackage[index].trackings.sort(function (a, b) {
      return order
        ? Number(a.tat) - Number(b.tat)
        : Number(b.tat) - Number(a.tat);
    });
    
  }



  /*
   * @Desc   : Sorting data according to Date - turn around time.
               Also orderOfTat shows the CSS class as asc/desc
               Reset orderOfTat for no sort order
   * @Author : Arjun S
   * @Param  : Pass in true to sort in asc and false for desc.
   */
  sortWithDesc(sort: string, sortDone: boolean) {
    if (sortDone) {
      this.loaderService.isLoaderEnable(true);      
      if(sort === 'asc'){
        this.activeSortAsc = true
      }else{
        this.activeSortDes = true
      }
        if (this.activeSortAsc) {
          this.sortAsc = true;
          this.activeSortAsc = false;
        }else{
          this.activeSortAsc = false
        }
      this.duplicateFilter.sort = sort;
      this.getPackages(this.duplicateFilter, true);
    } else {
      this.activeSortDes = false;
      this.activeSortAsc = false;
      this.loaderService.isLoaderEnable(true);
      this.duplicateFilter.sort = null;
      this.getPackages(this.duplicateFilter, true);
    }
  }

  sortWithAsc(sort: string, sortDone: boolean) {
    if (sortDone) {
      this.loaderService.isLoaderEnable(true);
      if(sort === 'asc'){
        this.activeSortAsc = true;
      } else{
        this.activeSortDes = true;
      }      
        if ( this.activeSortDes) {
          this.sortDec = true;
          this.activeSortDes = false;
        }else{
          this.activeSortDes = false
        }
        this.duplicateFilter.sort = sort;
        this.getPackages(this.duplicateFilter, true);
    } else {
      this.activeSortDes = false;
      this.activeSortAsc = false;
      this.loaderService.isLoaderEnable(true);
      this.duplicateFilter.sort = null;
      this.getPackages(this.duplicateFilter, true);
    }
  }

  /*
   * @desc: select a person from dropdown for filter.
   * @author: Abhiram M Sajeev
   */
  selectedIntakePerson(event: any): void {
    this.filterPerson = event;
  }

  /*
   * @desc: select a channel from dropdown for filter.
   * @author: Abhiram M Sajeev
   */
  selectedChannel(event: any): void {
    this.filterChannel = event;
  }

  /*
   * @desc: select a courier from dropdown for filter.
   * @author: Abhiram M Sajeev
   */
  selectedCourier(event: any): void {
    this.filterCourier = event;
  }

  /*
   * @desc: clear applyed filter.
   * @author: Abhiram M Sajeev
   */
  resetFilter(): void {
    this.range.patchValue({
      start: '',
      end: '',
    });
    this.filterTrackingNumber.patchValue('');
    this.filterPerson = 0;
    this.filterChannel = 0;
    this.filterCourier = 0;
    this.startDate = '';
    this.endDate = '';
    this.isApplyfilter = false;
    const packageListigRequest = new PackageListigRequest(
      this.recordsPerPage,
      this.currentPage,
      this.filterTrackingNumber.value,
      this.filterCourier,
      this.filterChannel,
      this.filterPerson,
      this.startDate,
      this.endDate
    );
    this.duplicateFilter = packageListigRequest;
    this.getPackages(packageListigRequest, true);
  }

  /*
   * @desc: apply new filter.
   * @author: Abhiram M Sajeev
   */
  applyFilter(): void {    
    this.currentPage = 1;
    this.isApplyfilter = true;
    this.sortAsc = true;
    this.sortDec = true;
    this.activeSortDes = false;
    this.activeSortAsc = false;
    this.startDate = this.range.controls.start.value
      ? moment(this.range.controls.start.value).format('YYYY-MM-DD')
      : '';
    this.endDate = this.range.controls.end.value
      ? moment(this.range.controls.end.value).format('YYYY-MM-DD')
      : '';
    const trackingNo = this.filterTrackingNumber.value
      ? this.filterTrackingNumber.value
      : '';
    const packageListigRequest = new PackageListigRequest(
      this.recordsPerPage,
      this.currentPage,
      trackingNo,
      this.filterCourier,
      this.filterChannel,
      this.filterPerson,
      this.startDate,
      this.endDate
    );
    this.duplicateFilter = { ...packageListigRequest };
    this.getPackages(this.duplicateFilter, true);
  }

  /*
   * @desc: calculate total count of the allocated channel aganist a intake.
   * @author: Abhiram M Sajeev
   */
  totalChannelCounter(channels: ChannelsPayaload[]) {
    let count = 0;
    channels.forEach((value) => {
      count = count + +value.channelCount;
    });
    return count;
  }

  /*
   * @desc: update the channel aganist the intake.
   * @author: Abhiram M Sajeev
   */
  changeChannel(
    channelId: any,
    intakeId: number,
    trackingNo: string,
    index: number
  ) {
    let req: ChanneUpdateRequest = {
      intakeId: intakeId,
      trackingNumber: trackingNo,
      channelId: channelId,
    };
    this.index = index;
    this.updateChannel(req);
  }
  /*
   * @desc: to check open current element.
   * @author: Nilena Alexander
   */
  openElement() {
    if (Number(this.index) >= 0)
      this.intakePackage[Number(this.index)].isExpandRow = true;
  }
  /*
   * @desc: to update channel api
   * @author: Abhiram M Sajeev
   */
  updateChannel(req: ChanneUpdateRequest) {
    this.loaderService.isLoaderEnable(true);
    this.packageService.updateChannel(req).subscribe(
      (res) => {
        if (res.success) {
          this.alertandToast.alert.toast({
            title: 'Success',
            type: 'success',
            message: res.message,
          });
          this.sortAsc = true;
          this.sortDec = true;
          this.activeSortDes = false;
          this.activeSortAsc = false;
          this.getPackages(this.duplicateFilter, false);
        } else {
          this.alertandToast.alert.toast({
            title: 'Error',
            type: 'error',
            message: res.message,
          });
        }
        this.loaderService.isLoaderEnable(false);
      },
      (error: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.apiHttpErrorHandler(error);
      }
    );
  }


    /*
   * @desc : Dispaly toaster message http error 
   * @author Manaf
   */
  
  apiHttpErrorHandler(err : HttpErrorResponse){
    this.alertandToast.alert.toast({
      title: 'Error',
      type: 'error',
      message: err.message,
    });  
   }
  /*
   * @desc : go back 
   * @author abhiram
   */

  backToNotifyFunc() {
    this.commentSliderToggle(false);
  }

  /*
   * @Desc   : Sending data to comments/notify slider component.
   * @Author : Arjun S
   * @Param  : Pass in the scanned items array of datatype scannedItems.
   */
  commentSlider(item: any, isComment: boolean, index: number) {
    this.index = index;    
    this.commentSliderLabel = isComment ? 'Comments' : 'Notify';    
    this.commentSliderIcon = isComment ? 'comments' : 'notify';    
    this.viewCommentsSection = isComment ? true : false;    
    this.showEmailSection = isComment ? false : true;    
    this.ViewchannelSection = isComment ? false : true;    
    this.showNotificationSection = isComment ? false : true;

    const obj = {
      trackingNumber: item.trackingNumber,
      trackingId: item.trackId,
      channelObj: item.channels,
    };
    this.commentSliderData = obj ? obj : {};

    this.commentSliderToggle(true);
  }

  /*
   * @Desc   : Close and open the comments/notify slider component.
   * @Author : Arjun S
   * @Param  : Pass in true/false top open/close vise versa.
   */
  commentSliderToggle(openOrClose: boolean) {
    if (openOrClose) {
      this.render.addClass(document.getElementById('bodyModal'), 'modal-open');
    } else {
      this.render.removeClass(
        document.getElementById('bodyModal'),
        'modal-open'
      );
      this.getPackages(this.duplicateFilter, false);
      this.getChannelAndCourierData();
    }

    this.showCommentSlider = openOrClose ? true : false;
  }

  /*
   * @Desc   : Close and open the comments/notify slider component.
   * @Author : Arjun S
   * @Param  : Pass in true/false top open/close vise versa.
   */
  notifyInternalPackageToggle(
    openOrClose: boolean,
    trakingData: PackagesPayaload
  ) {
    this.trackingData = trakingData;
    this.render.addClass(document.getElementById('bodyModal'), 'modal-open');
    this.showNotifyInternalPackage = openOrClose ? true : false;
  }

  /*
   * @Desc   : close notify page.
   * @Author : Abhiram M Sajeev
   */
  closeNotifyPage(): void {
    this.render.removeClass(document.getElementById('bodyModal'), 'modal-open');
    this.showNotifyInternalPackage = false;
  }

  showPrintScreenFun(intekeid: number) {
    this.printScreenToggle(true);
    this.intakeId = intekeid;
  }

  printScreenToggle(openOrClose: boolean) {
    this.showPrintScreen = openOrClose ? true : false;
  }

   /*
   * @Desc   : for disable the bell icon if the channel notification is false.
   * @Author : Abhiram M Sajeev
   * @Param  : Pass in the scanned items array of datatype scannedItems.
   */
  disableBellIcon(value: any): boolean {
  let x = [];
  x = value.filter((element: any) => element.allowNotification === true);
    if(x.length > 0) {
      return true
    } else {
      return false
    }
  }
}
