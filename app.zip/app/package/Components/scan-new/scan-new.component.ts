import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  HostListener,
  Renderer2,
} from '@angular/core';
import {
  CourierAgntList,
  ScanedItems,
  Channels,
  SaveTrackingItem,
  AddComments,
  ChanneUpdateRequest,
  Receipt,
} from '../../../core/Models/Interfaces/package';
import { AlertandtoasterService } from '../../../shared/Services/alertandtoaster.service';
import { PackageService } from '../../Services/package.service';
import { HttpErrorResponse } from '@angular/common/http';
import { LoaderService } from 'src/app/core/Services/loader.service';

@Component({
  selector: 'app-scan-new',
  templateUrl: './scan-new.component.html',
  styleUrls: ['../../../../assets/style/css/packages.css'],
})
export class ScanNewComponent implements OnInit {
  @ViewChild('title') title!: ElementRef;
  @ViewChild('tracking') tracking!: ElementRef;

  @HostListener('window:beforeunload', ['$event']) unloadHandler(event: Event) {
    if (this.scanedItems.length) {
      event.returnValue = false;
    }
  }
  courierId : number = 0;
  printData !: Receipt;
  intakeId  !: number;
  comments  : string = '';
  takeCount !: ScanedItems;
  orderOfTat : string = '';
  trackingNo !: string;
  trackingNoErr  : boolean = false;
  showPrintScreen: boolean = false;
  selectedCourierAgent: boolean = false;
  showCommentSlider   : boolean = false;
  showAlert           : boolean = false;
  commentSliderData!: ScanedItems;
  scanedItems       : ScanedItems[] = [];
  courierAgntList   : CourierAgntList[] = [];
  channelArrayList  : Channels[] = [];
  constructor(
    private alertandtoaster: AlertandtoasterService,
    private packageService: PackageService,
    private loaderService: LoaderService,
    private render: Renderer2
  ) { }

  ngOnInit(): void {
    this.getChannelandCourier();
  }
  ngAfterViewInit() {
    this.title?.nativeElement?.focus();
  }
  /*
   * @desc: to list Courier and channels via fork join.
   * @author: Elizabeth Mathew
   * @modify: Abhiram M Sajeev
   * @params: pass a boolean value for include the user details api (if pass true include user details get api)
   */
  getChannelandCourier() {
    this.loaderService.isLoaderEnable(true);
    this.packageService.getChannelAndCourierData(false).subscribe(
      (response) => {
        if (response[0].success) {
          let channellist = response[0];
          this.channelArrayList = channellist.data.channels;
        } else {
          this.channelArrayList = [];
        }
        if (response[1].success) {
          let courierlist = response[1];
          this.courierAgntList = courierlist.data.couriers;
        } else {
          this.courierAgntList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: err?.error?.message,
        });
      }
    );
  }

  /*()
   * @desc tocheck duplicate tracking number
   * @author Arjun S
   */
  getTrackingItem(event?:any) {
    let duplicateTackingNo = this.scanedItems.find(
      (el: ScanedItems) => el.trackingNumber === this.trackingNo?.trim()
    );
    let duplicateTackingNo2 = this.scanedItems.find(
      (el: ScanedItems) => el.trackingNumber.replace(/ /g, '') === this.trackingNo?.trim().replace(/ /g, '')
    );

    if (duplicateTackingNo2) {
      this.trackingNoErr = true;
      return;
    }

    if (duplicateTackingNo) {
      this.trackingNoErr = true;
      return;
    } else {
      this.trackingNoErr = false;
    }
    if (!this.trackingNo?.trim()) {
      return;
    }
    this.orderOfTat = '';
    this.saveScanedItem();
    this.trackingNo = '';
  }

  checkValid(event:Event){
    event.preventDefault();
    setTimeout(() => {
      this.tracking?.nativeElement?.focus();
    },);
  
}
  /*
   * @desc to save tracking item to DB
   * @author Nilena Alexander
   */
  saveScanedItem() {
    this.loaderService.isLoaderEnable(true);
    let payload: SaveTrackingItem = {
      intakeId: this.scanedItems.length ? this.scanedItems[0].intakeId : null,
      trackingNumber: this.trackingNo,
      courierId: this.courierId,
    };
    this.packageService.saveTrackingItem(payload).subscribe(
      (response) => {
        if (response.success) {
          

          this.scanedItems.unshift({
            intakeId: response.data.intake.intakeId,
            slNo: this.scanedItems.length + 1,
            trackingNumber: response.data.intake.trackingNumber,
            tat: response.data.intake.tat
              ? response.data.intake.tat.toString()
              : '0'.toString(),
            channelObj: response.data.intake.channel,
            trackingId: response.data.intake.trackingId,
            userId: response.data.intake.userId,
          });
          this.loaderService.isLoaderEnable(false);
        } else {
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response.message,
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.apiHttpErrorHandler(err);
      }
    );
  }

  /*
   * @desc : Dispaly toaster message http error 
   * @author Manaf
   */
  
  apiHttpErrorHandler(err : HttpErrorResponse){
    this.alertandtoaster.alert.toast({
      title: 'Error',
      type: 'error',
      message: err.message,
    });  
   }
  /*
   * @desc to save tracking item to DB
   * @author Nilena Alexander
   */
  addComments(index: number) {
    if (!(this.scanedItems && this.scanedItems[index]?.comments?.trim())) {
      return;
    }
    this.loaderService.isLoaderEnable(true);
    let payload: AddComments = {
      trackingId: this.scanedItems[index].trackingId,
      comment: this.scanedItems[index].comments,
      userId: this.scanedItems[index].userId,
      flag: true,
    };
    this.packageService.addComments(payload).subscribe(
      (response) => {
        if (response.success) {
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Success',
            type: 'success',
            message: response.message,
          });
        } else {
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response.message,
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.apiHttpErrorHandler(err);        
      }
    );
  }

  /*
   * @desc to select a courier agent
   * @author Nilena Alexander
   * @param array contains list of agent
   */
  selectedCourier(event: any) {
    this.selectedCourierAgent = event ? true : false;
    this.courierId = event;
    setTimeout(() => {
      this.tracking?.nativeElement?.focus();
    });
  }

  /*
   * @desc: update the channel aganist the intake.
   * @author: Abhiram M Sajeev
   */

  changeChannel(channelId: any, intakeId: number, trackingNo: string, index: number) {
    let channel = this.channelArrayList?.find(
      (el: Channels) => el.channelId === channelId
    );
    this.scanedItems[index].channelObj = channel;

    let req: ChanneUpdateRequest = {
      intakeId: intakeId,
      trackingNumber: trackingNo,
      channelId: channelId,
    };
    this.updateChannel(req, index);
  }
  /*
   * @desc: update the channel aganist the intake.
   * @author: Abhiram M Sajeev
   */
  updateChannel(req: ChanneUpdateRequest, index: number) {
    this.loaderService.isLoaderEnable(true);
    this.packageService.updateChannel(req).subscribe(
      (res) => {
        if (res.success) {
          let channel = this.channelArrayList.find(
            (el: Channels) => el.channelId === req.channelId
          );
          this.scanedItems[index].channelObj = channel;
          this.alertandtoaster.alert.toast({
            title: 'Success',
            type: 'success',
            message: res.message,
          });
        } else {
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: res.message,
          });
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.apiHttpErrorHandler(err);        
      }
    );
  }
  /*
   * @desc to delete a scanned item
   * @author Nilena Alexander
   * @param index
   */
  deleteEntry(index: number, trackingId: number) {
    this.alertandtoaster.alert
      .confirm({
        text: 'Do you want to Delete this record?',
        type: 'warning',
        cancelText: 'No',
        okText: 'Yes',
        title: 'Confirmation',
      })
      .then((res: any) => {
        if (res) {
          this.loaderService.isLoaderEnable(true);
          this.deleteTrackingItem(index, trackingId);
        }
      });
  }

  /*
   * @Desc   : Api intiating to Delete an item
   * @Author : Nilena Alexander
   */

  deleteTrackingItem(index: number, trackingId: number) {
    this.packageService.deleteTrackingItems(trackingId).subscribe(
      (response) => {
        if (response.success) {
          if(this.scanedItems.length === 1){
            this.cancelApitrigger();
            this.scanedItems.splice(index, 1);
          }
          else{
            this.scanedItems.splice(index, 1);
          }
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Success',
            type: 'success',
            message: response.message,
          });
        } else {
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response.message,
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.apiHttpErrorHandler(err);
      }
    );
  }

  /*
   * @Desc   : confirmation popup for all the records have been submitted.
   * @Author : Elizabeth Mathew
   */
  confirm() {
    this.alertandtoaster.alert
      .confirm({
        text: `You have scanned in ${this.scanedItems.length} item(s)`,
        type: 'success',
        hideCancelButton: false,
        cancelText: 'Go Back',
        okText: 'Print Receipt',
        title: 'Confirmation',
        addditionalButton: {
          buttonText: "Start New Scan",
          actionFunction: this.clearAndNewScan
        }
      })
      .then((res: any) => {
        if (res) {
          this.showPrintScreen = true;
        }
      });
  }
   /*
   * @Desc   : clearing functionality when clicking on the scan again button from the confirmation popup
   * @Author : Elizabeth Mathew
   */
  clearAndNewScan=()=>{
    this.scanedItems = [];
    this.alertandtoaster.alert.toast({
      title: 'Success',
      type: 'success',
      message: 'Your Intake has been Saved',
    });
  }
  /*
   * @desc to cancel all scanned items
   * @author Nilena Alexander
   */
  cancel() {
    if (this.scanedItems && this.scanedItems.length) {
      this.alertandtoaster.alert
        .confirm({
          text: 'Do you want to remove all records?',
          type: 'warning',
          hideCancelButton: false,
          cancelText: 'No',
          okText: 'Yes',
          title: 'Confirmation',
        })
        .then((res: any) => {
          if (res) {
            this.cancelApitrigger();
          } 
        });
    }
  }
  /*
  * @desc to call cancel api
  * @author Nilena Alexander
  */
  cancelApitrigger() {
    this.loaderService.isLoaderEnable(true);
    this.packageService.deleteIntake(this.scanedItems[0].intakeId).subscribe(
      (response) => {
        if (response.success) {
          this.scanedItems = [];
          this.courierAgntList = [];
          this.selectedCourierAgent = false;
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Success',
            type: 'success',
            message: response.message,
          });
        } else {
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response.message,
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.apiHttpErrorHandler(err);        
      }
    );
  }

  /*
   * @Desc   : Sorting data according to TAT - turn around time.
               Also orderOfTat shows the CSS class as asc/desc
               Reset orderOfTat for no sort order
   * @Author : Arjun S
   * @Param  : Pass in true to sort in asc and false for desc.
   */
  sortWithTat(order: boolean) {
    this.orderOfTat = order ? 'ascending' : 'descending';
    let withNa: any = this.scanedItems.filter((el: ScanedItems) => el.tat === 'NA');
    this.scanedItems = this.scanedItems.filter((el: ScanedItems) => el.tat !== 'NA');
    this.scanedItems.sort(function (a, b) {
      return order
        ? Number(a.tat) - Number(b.tat)
        : Number(b.tat) - Number(a.tat);
    });
    withNa.map((el: ScanedItems) => this.scanedItems.push(el));
  }

  /*
   * @Desc   : Sending data to comments/notify slider component.
   * @Author : Arjun S
   * @Param  : Pass in the scanned items array of datatype scannedItems.
   */
  commentSlider(item: ScanedItems) {
    this.commentSliderData = item;
    this.commentSliderToggle(true);
  }

  /*
   * @Desc   : Close and open the comments/notify slider component.
   * @Author : Arjun S
   * @Param  : Pass in true/false top open/close vise versa.
   */
  commentSliderToggle(openOrClose: boolean) {
    if (openOrClose) {
      this.showCommentSlider = true;
      this.render.addClass(document.getElementById('bodyModal'), "modal-open")
    } else {
      this.showCommentSlider = false;
      this.render.removeClass(document.getElementById('bodyModal'), "modal-open");
    }

  }

  AlertToggle(closeAlert: boolean) {
    this.showAlert = closeAlert ? true : false;
  }

  /*
   * @Desc   : Open Print screen after clicked on save and print in the Confirmation popup.
   * @Author : Elizabeth Mathew
   */
  printScreenToggle() {
    this.showPrintScreen = true;
    this.showAlert = false;
  }

  /*
   * @Desc   : Get Receipt details
   * @Author : Nilena Alexnder
   */
  getReceiptDetails() {
    this.loaderService.isLoaderEnable(true);
    this.packageService.getReceipt(this.scanedItems[0].intakeId).subscribe(
      (response) => {
        if (response.success) {
          this.printData = response.data.receipt;
          this.showPrintScreen = true;
          this.loaderService.isLoaderEnable(false);
        } else {
          this.showPrintScreen = false;
          this.loaderService.isLoaderEnable(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response.message,
          });
        }
      },
      (err: HttpErrorResponse) => {
        this.showPrintScreen = false;
        this.loaderService.isLoaderEnable(false);
        this.apiHttpErrorHandler(err);
      }
    );
  }
  /*
   * @Desc   : To close print and receipt popup
   * @Author : Nilena Alexnder
   */
  closeReceipt() {
    this.showPrintScreen = false;
  }
}
