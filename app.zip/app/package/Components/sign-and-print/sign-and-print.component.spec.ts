import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SignAndPrintComponent } from './sign-and-print.component';

describe('SignAndPrintComponent', () => {
  let component: SignAndPrintComponent;
  let fixture: ComponentFixture<SignAndPrintComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SignAndPrintComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SignAndPrintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
