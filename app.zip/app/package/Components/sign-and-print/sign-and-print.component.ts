import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Receipt } from 'src/app/core/Models/Interfaces/package';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { PackageService } from '../../Services/package.service';

@Component({
  selector: 'app-sign-and-print',
  templateUrl: './sign-and-print.component.html',
  styleUrls: ['./sign-and-print.component.css']
})
export class SignAndPrintComponent implements OnInit {

     public pdfSrc: SafeHtml | null= null;
     @Output() closeSignAndPrint: EventEmitter<boolean> = new EventEmitter<boolean>();
     printData!: Receipt;
     @Input() 
     intakeId!: number;

  constructor(private sanitizer:DomSanitizer, private loaderService: LoaderService,
    private packageService: PackageService, private alertandtoaster: AlertandtoasterService) {

  }
  ngOnInit(): void {
    this.getReceiptDetails(this.intakeId);
  }

    /*
   * @Desc   : Get Receipt details
   * @Author : Nilena Alexnder
   */
    getReceiptDetails(intakeId: number) {
      this.loaderService.isContentLoader(true);
      this.packageService.getReceipt(intakeId).subscribe(
        (response) => {
          if (response.success) {
            this.printData = response.data.receipt;
            this.fileChangeEvent(this.printData)
            this.loaderService.isContentLoader(false);
          } else {
            this.loaderService.isContentLoader(false);
            this.alertandtoaster.alert.toast({
              title: 'Error',
              type: 'error',
              message: response.message,
            });
          }
        },
        (err: HttpErrorResponse) => {
          this.loaderService.isContentLoader(false);
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: err?.error?.message,
          });
        }
      );
    }


  /*
   * @Desc   : converted blob to pdf
   * @Author : Nilena Alexander
   * @Param  : encodedata,filename and type of file
   */
  fileChangeEvent(fileInput: Receipt) {
    let byteCharacters = atob(fileInput.receiptPdfEncoded);
    let byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    let byteArray = new Uint8Array(byteNumbers);
    let file = new Blob([byteArray], { type: 'application/pdf;base64' });
    let fileURL = URL.createObjectURL(file);
    this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
  }
  
/*
   * @Desc   :to close receipt page
   * @Author : Nilena Alexander
   */
  close(){
    this.closeSignAndPrint.emit(false);
  }

}
