import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from '../../../core/Services/loader.service';

@Component({
  selector: 'app-content-loader',
  templateUrl: './content-loader.component.html',
  styleUrls: ['./content-loader.component.css']
})
export class ContentLoaderComponent {
  subscription: Subscription;
  isLoader: boolean = false;
  constructor(private loaderService: LoaderService) {
    this.subscription = this.loaderService.getContentLoader().subscribe((res)=> {
      this.isLoader = res;
    });
   }
  

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
