import { Component, OnInit, Renderer2, ViewChild, ElementRef, HostListener } from '@angular/core';
import { AlertType, AlertInfoTrigger } from 'src/app/core/Models/Interfaces/Alert&Toast';
import { AlertandtoasterService } from '../../Services/alertandtoaster.service';

@Component({
  selector: 'app-alert-box',
  templateUrl: './alert-box.component.html',
  styleUrls: ['./alert-box.component.css']
})
export class AlertBoxComponent implements OnInit {

  public showAlert: boolean = false;
  private resolve: any;
  public title: string = '';
  public text: string = '';
  public type: AlertType = 'success';
  public hideCancelButton: boolean = false;
  public hideOkButton: boolean = false;
  public okText: string = 'Ok';
  public cancelText: string = 'Cancel';
  public additionalButton : any;
  public iconMap = {
    'success': 'success',
    'error': 'err',
    'warning': 'warning',
    'info': 'info',
    'warning-icon' : 'warning-icon'
  }
  public isTitleCash: boolean | undefined = false;

  @ViewChild('titleFoc') titleFoc!: ElementRef;
  @ViewChild('close') close!: ElementRef;

  constructor(
    private alertandtoaster : AlertandtoasterService,
    private renderer: Renderer2,
  ) { }

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if(event.target.id === "success" && (event.code === 'Tab' || event.key === 'Tab') ){
      this.close?.nativeElement.focus();
      event.preventDefault();
    }
    if(event.code === 'Escape' || event.key === 'Escape'){
      this.confirm(false);
    }
  }


  ngOnInit(): void {
    this.alertandtoaster.alertTrigger$.subscribe(({ type, title, text, okText, cancelText, hideCancelButton, hideOkButton, resolve, isTitleCash,addditionalButton }: AlertInfoTrigger) => {
      this.showAlert = true;
      this.resolve = resolve;
      this.type = type;
      this.title = title;
      this.text = text;
      this.okText = okText || 'Ok';
      this.cancelText = cancelText || 'Cancel';
      this.hideCancelButton = hideCancelButton || false;
      this.hideOkButton = hideOkButton || false;
      this.isTitleCash = isTitleCash;
      this.additionalButton = addditionalButton;
      setTimeout(()=> {
        this.titleFoc?.nativeElement.focus();
      });
      
    })
  }

  confirm(status: boolean) {
    this.resolve(status);
    this.showAlert = false;
  }
  /*
   * @desc: scan again extra button functionality
   * @author: Elizabeth Mathew
   */
  confirmAdditionalBtn(){
    this.additionalButton.actionFunction();
    this.showAlert = false;
  }

}
