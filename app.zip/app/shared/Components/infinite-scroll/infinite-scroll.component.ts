import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  ViewChild,
} from '@angular/core';

@Component({
  selector: 'app-infinite-scroll',
  templateUrl: './infinite-scroll.component.html',
  styleUrls: ['./infinite-scroll.component.css'],
})
export class InfiniteScrollComponent implements AfterViewInit, OnDestroy {
  /**
   * @author Arun Lalithambaran
   * @description Infinite scroll listener component
   * Wrap the list with <app-infinite-scroll> and give the scoll property ( overflow-x: auto).
   * The component will emit (scrolled) event if scroll botoom reached.
   * important: overflow-x must be added to <app-infinite-scroll> element
   * Example: <app-infinite-scroll (scrolled)="getList()"></app-infinite-scroll>
   * getList() {
   *  if(!loading) {
   *    loading = true;
   *    apilogic...
   *  }
   * }
   */

  @Input() options: any = {};
  @Input() disableLoader: boolean = false;
  @Output() scrolled: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild('anchorElement') anchor!: ElementRef<HTMLElement>;

  private observer!: IntersectionObserver;

  constructor(private host: ElementRef) {}

  private get element(): HTMLElement {
    return this.host?.nativeElement;
  }

  ngAfterViewInit(): void {
    const options = {
      root: this.isHostSrollable() ? this.host.nativeElement : null,
      ...this.options,
    };
    this.observer = new IntersectionObserver(([entry]) => {
      this.hasScroll() && entry.isIntersecting && this.scrolled.emit();
    }, options);
    this.observer.observe(this.anchor.nativeElement);
  }

  private isHostSrollable() {
    const style = window.getComputedStyle(this.element);
    return (
      style.getPropertyValue('overflow-y') === 'auto' ||
      style.getPropertyValue('overflow-y') === 'scroll'
    );
  }

  private hasScroll() {
    try {
      const style = window.getComputedStyle(this.element);
      const height = Number(style.getPropertyValue('height').split('px')[0]);
      const maxHeight = Number(
        style.getPropertyValue('max-height').split('px')[0]
      );
      return height > maxHeight;
    } catch (err) {
      return false;
    }
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
