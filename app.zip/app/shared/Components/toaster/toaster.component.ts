import { Component, OnInit } from '@angular/core';
import { CONSTANTS } from 'src/app/core/Constants/constants';
import { Toast } from 'src/app/core/Models/Interfaces/Alert&Toast';
import { AlertandtoasterService } from '../../Services/alertandtoaster.service';

@Component({
  selector: 'app-toaster',
  templateUrl: './toaster.component.html',
  styleUrls: ['./toaster.component.css'],
})
export class ToasterComponent implements OnInit {
  public iconClass: { [key: string]: string } = CONSTANTS.alertClass;
  public toastMessage: any;
  public btnShow = false;
  constructor(private alertandtoaster: AlertandtoasterService) {}

  ngOnInit(): void {
    this.alertandtoaster.toasterTigger$.subscribe((toast: Toast) => {
      if (!toast.title) {
        return;
      }
      this.toastMessage = toast;
      setTimeout(() => {
        this.makeToastEmpty(this.toastMessage);
      },2000);
    });

   
  }

  makeToastEmpty(toast: Toast) {
    this.toastMessage= null;
  }
}
