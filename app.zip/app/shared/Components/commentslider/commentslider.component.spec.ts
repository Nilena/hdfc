import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentsliderComponent } from './commentslider.component';

describe('CommentsliderComponent', () => {
  let component: CommentsliderComponent;
  let fixture: ComponentFixture<CommentsliderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommentsliderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommentsliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
