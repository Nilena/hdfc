import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AlertandtoasterService } from '../../../shared/Services/alertandtoaster.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { SharedService } from '../../Services/shared.service'
import { AddComments, AddNotificationPayload } from '../../../core/Models/Interfaces/package';
import { UtilityService } from '../../Services/utility.service';

@Component({
  selector: 'app-commentslider',
  templateUrl: './commentslider.component.html',
  styleUrls: ['./commentslider.component.css']
})
export class CommentsliderComponent implements OnInit {

  //Element Reference
  @ViewChild('title') title!: ElementRef;
  @ViewChild('commentBox') commentBox!: ElementRef;

  //Inputs
  @Input() commentSliderData !: any;
  @Input() label: string = '';
  @Input() iconClass: string = '';

  @Input() ViewchannelSection: boolean = true;
  @Input() showEmailSection: boolean = true;
  @Input() viewCommentsSection: boolean = false;
  @Input() fromIntenalPackage: boolean = false;
  @Input() showNotificationSection: boolean = false;

  //Outputs
  @Output() closeComponent: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() backtoNotify: EventEmitter<boolean> = new EventEmitter<boolean>();


  showSlider: boolean = false;
  submitted: boolean = false;
  // public commentSliderForm: FormGroup;

  defaultEmail: string[] = [];  
  emailIDList: any = [];
  notificationsList: any = [];
  commenntsList: any = [];

  commentInvalid: boolean = false;
  commmentVariable: string = "";

  notificationMsgVariable: string = "";
  notificationMsgInvalid: boolean = false;
  emailInvalid: boolean = false;
  emailStringList: string[] = [];

  constructor(
    private fb: FormBuilder,
    private alertandtoaster: AlertandtoasterService,
    private http: HttpClient,
    private loaderService: LoaderService,
    private sharedService: SharedService,
    private utilityService: UtilityService
  ) {    
  }

  ngOnInit(): void {    
    if (this.commentSliderData.channelObj.defaultEmail) {
      this.defaultEmail.push(this.commentSliderData.channelObj.defaultEmail)
    }

    // Get comments only if its a comment slider request
    if (this.viewCommentsSection) {
      this.getComments();
    }

    // Get notifications and email list only if its a notification slider request
    if (this.showNotificationSection) {
      this.getEmailList();
      this.getNotifications();
    }


    // To focus on comment box when the slider is clicked.
    setTimeout(() => {
      this.commentBox.nativeElement.focus();
    }, 500);

  }

  /*
 * @Desc   : To give a slider animation on click after view
 * @Author : Arjun S
 * @Param  : Nill
 */
  ngAfterViewInit() {
    setTimeout(() => {
      this.showSlider = true;
    });
  }


  /*
   * @Desc   : Get Email list for providing in the email multiselect component.
   * @Author : Arjun S
   * @Param  : 
   */
  getEmailList() {
    this.loaderService.isContentLoader(true);
    let channel = this.commentSliderData.channelObj.channelId;
    this.sharedService.getEmailsForChannelId(channel)
      .subscribe(response => {
        if (response.success) {
          this.emailIDList = response.data.contacts;
        }
        // else 
        // {
        //   this.loaderService.isLoaderEnable(false);
        //   this.alertandtoaster.alert.toast({
        //     title: 'Error',
        //     type: 'error',
        //     message: response.message,
        //   })
        // }
        this.loaderService.isContentLoader(false);

      }, (err: HttpErrorResponse) => {
        this.loaderService.isContentLoader(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: err?.error?.message,
        });
      });
  }


  /*
   * @Desc   : Get comment list for showing in the comments section.
   * @Author : Arjun S
   * @Param  : 
   */
  getComments() {
    this.loaderService.isContentLoader(true);
    this.sharedService.getCommentsForTrackingId(this.commentSliderData?.trackingId)
      .subscribe(response => {
        if (response.success) {
          this.commenntsList = response.data.trackingComments;
        }
        // else {
        //   this.loaderService.isLoaderEnable(false);
        //   this.alertandtoaster.alert.toast({
        //     title: 'Error',
        //     type: 'error',
        //     message: response.message,
        //   })
        // }
        this.loaderService.isContentLoader(false);

      }, (err: HttpErrorResponse) => {
        this.loaderService.isContentLoader(false);
        this.utilityService.apiHttpErrorHandler(err);
      });
  }

  /*
   * @Desc   : Posting comments with user Id .
   * @Author : Arjun S
   * @Param  : (flag false - inside comments slider)
   */
  addComments(comment: string) {
    if (!(comment.trim())) {
      this.commentInvalid = true;
      return;
    }

    this.loaderService.isContentLoader(true);
    let payload: AddComments = {
      trackingId: this.commentSliderData?.trackingId,
      comment: comment,
      userId: 1,
      flag: false,
    };
    this.sharedService.addComments(payload).subscribe((response) => {
      if (response.success) {
        this.loaderService.isContentLoader(false);
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: response.message,
        });
        this.commmentVariable = "";
        this.getComments();
      } else {
        this.loaderService.isContentLoader(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: response.message,
        })
      }
    },
      (err: HttpErrorResponse) => {
        this.loaderService.isContentLoader(false);
        this.utilityService.apiHttpErrorHandler(err);
      })
  }

  /*
   * @Desc   : Get notifications list for showing in the notification section.
   * @Author : Arjun S
   * @Param  : -
   */
  getNotifications() {
    this.loaderService.isContentLoader(true);
    this.sharedService.getNotificationsForTrackingId(this.commentSliderData?.trackingId)
      .subscribe(response => {
        if (response.success) {
          this.notificationsList = response.data.trackingNotifications;
        } 
        // else {
        //   this.loaderService.isLoaderEnable(false);
        //   this.alertandtoaster.alert.toast({
        //     title: 'Error',
        //     type: 'error',
        //     message: response.message,
        //   })
        // }
        this.loaderService.isContentLoader(false);

      }, (err: HttpErrorResponse) => {
        this.loaderService.isContentLoader(false);
        this.utilityService.apiHttpErrorHandler(err);
      })
  }



  /*
  * @Desc   : Posting comments with user Id .
  * @Author : Arjun S
  * @Param  : (flag false - inside comments slider)
  */
  addNotifications(notificationMsg: string) {
    if ((!(notificationMsg.trim())) || this.emailStringList.length === 0) {
      if (!(notificationMsg.trim())) {
        this.notificationMsgInvalid = true;
      }
      if (this.emailStringList.length === 0) {
        this.emailInvalid = true;
      }
      return;
    }

    this.loaderService.isContentLoader(true);
    let payload: AddNotificationPayload = {

      trackingId: this.commentSliderData?.trackingId,
      notifyTo: this.emailStringList.toString(),
      message: notificationMsg,
      userId: 1,
    };
    this.sharedService.addNotifications(payload).subscribe((response) => {
      if (response.success) {
        this.loaderService.isContentLoader(false);
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: response.message,
        });
        this.notificationMsgVariable = "";
        this.getNotifications();
      } else {
        this.loaderService.isContentLoader(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: response.message,
        })
      }
    },
      (err: HttpErrorResponse) => {
        this.loaderService.isContentLoader(false);
        this.utilityService.apiHttpErrorHandler(err);
      })
  }



  /*
   * @Desc   : Data coming back from the email multiselect component
   * @Author : Arjun S
   * @Param  : 
   */
  selectedData(selectedEmails: any) {
    this.emailStringList = selectedEmails.map(function (item: any) {
      return " "+item.label;
    });
  }


  /* Closes the comments slider on X button.Emit false to parent on close button. */
  closeCommentSlider() {
    setTimeout(() => {
      this.closeComponent.emit(false);
    }, 400);
    this.showSlider = false;
  }

  backToNotify() {
    this.backtoNotify.emit(true);
  }


}
