import { Component, OnInit, Input, HostListener, ViewChild, ElementRef, Output, EventEmitter, SimpleChanges } from '@angular/core';
@Component({
  selector: 'app-single-select',
  templateUrl: './single-select.component.html',
  styleUrls: ['../../../../assets/style/css/singleselect.css']
})
export class SingleSelectComponent implements OnInit {

  SearchItem: string = '';
  searchD: string = '';
  filteredArr: any = [];
  selectedItemName: string = 'Select';
  selectedItemChannel: string = '';
  searchText : string = '';
  displayList: boolean = false;
  selectedOption: any = null
  selectedItemId: string = ''
  sector = {} as any;
  _dataArr: any = [];
  @Input() uid: string = '';
  @Input() label: string = '';
  @Input() isDisabled: boolean = false;
  @Input() loader: boolean = false;
  @Input() SearchItem2: string = '';
  @Input() SearchItem1: string = '';
  @Input() channel: string = ''
  @Input() placeholder: string = 'Select';
  @Input ()searchShow:boolean = false;
  @Input() resetSearch : boolean = false;
  public objectX: any;
  @Output() selectedEvent = new EventEmitter<string>();
  @Output() selectedDisplayValue = new EventEmitter<string>();
  @Output() selectedObject = new EventEmitter<any>();
  @Output() searchEmitter =new EventEmitter<any>();


  @ViewChild('searchInput') searchInput!: ElementRef;
  @ViewChild('listitem') listitem!: ElementRef;
  
  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (!this._elementRef.nativeElement.contains(event.target)) {
      this.clickedOutside({});
    }
  }

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    // ArrowDown
    if (event.code === 'ArrowDown' || event.key === 'ArrowDown') {
      event.preventDefault();
      (document.activeElement?.nextSibling as HTMLElement)?.focus();
    }

    // ArrowUp
    if (event.code === 'ArrowUp' || event.key === 'ArrowUp') {
      event.preventDefault();
      (document.activeElement?.previousSibling as HTMLElement)?.focus();
    }

    //Close on escape
    if (event.code === 'Escape' || event.key === 'Escape') {
      this.clickedOutside({});
    }

   // Select on space
    if (event.code == 'Enter' || event.key == 'Enter') {

      if (this.displayList) {
        this.objectX = (this._dataArr.find((el: any) => el[`${this.label}`] == event.target.innerText));
        this.selectItem(this.objectX);
      }
      event.preventDefault();
    }
  }

  @Input() set dataArr(value: any[]) {
    this._dataArr = value;
    if (this._dataArr && this._dataArr.length) {
      this.filteredArr = [];
      this._dataArr.forEach((item: any) => {
        if (Number.isInteger(item) || item.length) {
          const obj: any = {};
          obj[this.uid] = item;
          obj[this.label] = item;
          this.filteredArr.push(obj);
        }
        else {
          this.filteredArr = this._dataArr;
        }
      });
    }else{
      this.filteredArr = this._dataArr;
    }
  }

  @Input() set selectedData(value: any) {
    if (value || (value === 0 && value !== '')) {
      this.selectedOption = value;
      this.setSelectedItem();
    } else {
      this.selectedItemId = '';
      this.selectedItemName = '';
      this.selectedOption = null;
    }
  }

  constructor(public _elementRef: ElementRef) { }

  // To show and hide drop down
  showDropdown() {
    if (!this.isDisabled) {
      this.displayList = !this.displayList;
      if(this.resetSearch && this.searchText){
          this.searchText = "";
          this.searchEmitter.emit(this.searchText);
      }
    }
  }


  ngOnChanges(changes: SimpleChanges) {
    if (this._dataArr && this._dataArr.length) {
      if (this.selectedOption) {
        this.setSelectedItem();
      } else {
        this.selectedItemId = '';
        this.selectedItemName = '';
      }

      let tempArray: any = [];
      tempArray = this.filteredArr.filter((el: any) => el[this.label] && el[this.label].toString().trim() !== '');
      this._dataArr = tempArray;
      this.filteredArr = tempArray;
    } else {
      this.selectedItemId = '';
      this.selectedItemName = '';
    }
  }

  ngOnInit(): void {
    this.SearchItem = this.label;
  }


  private setSelectedItem() {
    if (typeof (this.selectedOption) !== 'object') {
      const obj: any = {};
      obj[this.uid] = this.selectedOption ? this.selectedOption : null;
      obj[this.label] = this.selectedOption ? this.selectedOption : null;
      this.selectedOption = obj
    }
    if (this.selectedOption && this._dataArr) {
      let isAvailable = false;
      let selectedObject: any;
      this._dataArr.forEach((item: any) => {
        let retValue = this.selectTypChk(item,isAvailable,selectedObject);
        isAvailable = retValue[0];
        selectedObject = retValue[1];
      });
      if (isAvailable) {
        if (typeof (this.selectedOption) === 'string') {
          this.selectedItemId = this.selectedOption;
          this.selectedItemName = this.selectedOption;
        } else {
          this.selectedItemId = selectedObject[this.uid];
          this.selectedItemName = selectedObject[this.label];
          this.selectedItemChannel = selectedObject[this.channel];
        }
      }
    }
  }
  clickedOutside(event: any) {
    this.displayList = false;
  }

  selectItem = (item: any) => {
    this.displayList = false;
    this.selectedItemId = item[this.uid];
    this.selectedItemName = item[this.label];
    this.selectedItemChannel = item[this.channel];
    this.selectedEvent.emit(item[this.uid]);
    this.selectedDisplayValue.emit(item[this.label]);
    this.selectedObject.emit(item);
  }

  onEnter(key: string, item: any) {
    if (key === 'Enter') {
      this.selectItem(item);
    }
  }


  checkLimit(){
    if(this.searchText.length<1 || this.searchText.length>=2 && this.searchText.length<20){
      this.searchEmitter.emit(this.searchText);
    }
  }


  selectTypChk(item:any,isAvailable:boolean,selectedObject:any){
    if (typeof (this.selectedOption) !== 'object') {
          if (item[this.uid] === this.selectedOption) {
            isAvailable = true;
            selectedObject = item;
          }
        } else {
          if (item[this.uid] === this.selectedOption[this.uid]) {
            isAvailable = true;
            selectedObject = item;
          }
        }
        return [isAvailable, selectedObject]
  }
}
