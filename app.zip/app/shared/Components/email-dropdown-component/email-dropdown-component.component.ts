import { Component, Input, Output, EventEmitter, ChangeDetectorRef, SimpleChanges, HostListener, ViewChild, ElementRef } from '@angular/core';
import { Subscription, Subject } from 'rxjs';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { REGCONSTANTS } from '../../../core/Constants/regex-constants';

@Component({
	selector: 'app-email-dropdown-component',
	templateUrl: './email-dropdown-component.component.html',
	styleUrls: ['./email-dropdown-component.component.css', '../../../../assets/style/css/packages.css']
})
export class EmailDropdownComponentComponent  {
	@Input('data') data: any = [];
	@Input('keyName') keyValue: any;
	@Input('placeholder') placeholder: any;
	@Input('selectData') selectData: any = [];
	@Input('id') id: any;
	@Output() selectedData = new EventEmitter();
	@ViewChild('searchBox') searchBox!: ElementRef;


	@HostListener('document:click', ['$event'])
	clickout(event: any) {
		if (!this.searchBox?.nativeElement.contains(event.target)) {
			this.clickOutSide(true);
		}
	}

	enableDropDown: boolean = false;
	selectedValues: any;
	searchWord: any = '';
	selectedList: any = [];
	key: string = 'label';
	type: any;
	textField: any;

	public keyUp = new Subject<KeyboardEvent>();
	private subscription: Subscription;

	constructor(private change: ChangeDetectorRef) {
		this.subscription = this.keyUp.pipe(
			map((event: any) => event && event.target['value']),
			debounceTime(500),
			distinctUntilChanged(),
		).subscribe((val: any) => { this.search(val) });
	}

	

	ngOnChanges(changes: SimpleChanges) {
		let tempArray = [];
		for (let i = 0; i < this.data.length; i++) {
			tempArray.push({ id: (i + 1), label: this.data[i][this.keyValue], fsChecked: false, originalData: this.data[i] });
		}
		this.data = tempArray;
		if (this.data && this.selectData) {
			this.selectedList = [];
			this.fsCheckedDataIO();
		
			for (let i = 0; i < this.selectedList.length; i++) {
				tempArray.push(this.selectedList[i].label);
			}
			if (this.selectData)
				for (let i = 0; i < this.selectData.length; i++) {
					if (!tempArray.includes(this.selectData[i])) {
						this.selectedList.push({
							fsChecked: true, id: Number(this.data[i]?.id) + 1, label: this.selectData[i], originalData:
							{
								email: this.selectData[i]
							}
						});
					}
				}
			this.selectedData.emit(this.selectedList);
		}
	}


	fsCheckedDataIO() {
		for (let i = 0; i < this.data.length; i++) {
			for (let j = 0; j < this.selectData.length; j++) {
				if (!this.data[i].label)
					if (this.data[i].originalData.email) {
						this.data[i].label = this.data[i].originalData.email;
					}

					else {
						this.data[i].label = this.data[i].originalData.label;
					}
				if (this.selectData[j] === this.data[i].label) {
					this.selectedList.push(this.data[i]);
					this.selectedList = Object.values(this.selectedList.reduce((acc: any, cur: any) => Object.assign(acc, { [cur.label]: cur }), {}));
					this.data[i].fsChecked = true;
					break;
				}
			}
		}
	}



	onKeyDown(event: any) {
		if (((event.keyCode || event.charCode) === 8 || (event.keyCode || event.charCodekey) === 46) && this.textField.trim() === '') {
			if (this.selectedList.length) {
				let id = this.selectedList.pop().id;
				this.selectedData.emit(this.selectedList);
				let dataIndex = this.data.findIndex((x: any) => x.id === id);

				if (this.data[dataIndex])
					this.data[dataIndex].fsChecked = false;
			}
		}
		if (event.code === 'Tab' || event.code === 'Comma') {
			this.clickOutSide(true);
		}
		if (event.code === 'Enter' || event.key === 'Enter') {
			this.clickOutSide(true);
		}
	}

	select(data: any) {
		if (data.fsChecked) {
			let index = this.selectedList.findIndex((x: any) => x.id === data.id);
			this.selectedList.splice(index, 1);
			data.fsChecked = false;
		} else {
			data.fsChecked = true;
			this.selectedList.push(data);
		}

		let tempArray = [];
		if (this.type === 1) {
			for (let i = 0; i < this.selectedList.length; i++) {
				tempArray.push(this.selectedList[i].label);
			}
			this.selectedData.emit(tempArray);
		} else if (this.type === 2) {
			for (let i = 0; i < this.selectedList.length; i++) {
				tempArray.push(this.selectedList[i].originalData);
			}
		}
		this.textField = "";
		this.keyUp.next();
		this.enableDropDown = false;
		(document.getElementById(this.id) as HTMLElement)?.focus();
	}

	search(x: any) {
		if (x && x.trim() !== '') {
			this.enableDropDown = true;
			this.searchWord = x.trim();
		} else {
			this.enableDropDown = false;
			this.searchWord = '';
		}
	}

	remove(data: any) {
		let index = this.selectedList.findIndex((x: any) => x.id === data.id);
		this.selectedList.splice(index, 1);
		let dataIndex = this.data.findIndex((x: any) => x.id === data.id);
		if (this.data[dataIndex])
			this.data[dataIndex].fsChecked = false;


	}

	clickOutSide(event: any) {
		this.enableDropDown = false;
		if (this.textField) {
			this.checkEmail(this.textField);
		}

		this.textField = "";
		this.selectedData.emit(this.selectedList);
		this.keyUp.next();
	}

	focusText() {
		(document.getElementById(this.id) as HTMLElement)?.focus();
		setTimeout(() => {
			this.enableDropDown = true;
		});
	}

	checkEmail(value: any) {
		let email_exp = REGCONSTANTS.emailRegExp;
		if (email_exp.test(value)) {
			if (this.data.length) {
				this.selectedList.push({
					fsChecked: true, id: Number(this.data[this.data.length - 1].id) + 1, label: value, originalData:
						{ email: value }
				});
				this.textField = "";
				this.data.push({
					fsChecked: true, id: Number(this.data[this.data.length - 1].id) + 1, label: value, originalData:
						{ email: value }
				});
			} else {
				this.selectedList.push({
					fsChecked: true, id: 1, label: value, originalData:
						{ email: value }
				});
				this.textField = "";
				this.data.push({
					fsChecked: true, id: 1, label: value, originalData:
						{ email: value }
				});
			}
		}
	}
}