import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Toast, AlertInfoTrigger, AlertInfo  } from 'src/app/core/Models/Interfaces/Alert&Toast';

@Injectable({
  providedIn: 'root'
})
export class AlertandtoasterService {

  public toasterTigger$ : Subject <Toast> = new Subject ();
  public alertTrigger$: Subject<AlertInfoTrigger> = new Subject();
  public alert = {
    toast: (toast: Toast):void => {
      this.toasterTigger$.next(toast);
    },
    confirm: (config: AlertInfo): Promise<boolean> => {
      return new Promise((resolve, reject) => {
        let payload: AlertInfoTrigger = { ...config, resolve };
        this.alertTrigger$.next(payload);
      })
    },
  }
  
  
}
