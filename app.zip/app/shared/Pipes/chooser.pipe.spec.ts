import { ChooserPipe } from './chooser.pipe';

describe('ChooserPipe', () => {
  it('create an instance', () => {
    const pipe = new ChooserPipe();
    expect(pipe).toBeTruthy();
  });
});
