import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'chooser'
})

export class ChooserPipe implements PipeTransform {
  transform(value: any, searchWord: any, keyValue: any, type: any): any {
    value = value.filter((item:any)=>{
      return item.fsChecked === false;
    })
  
    let outPut: any = [];
    if (searchWord) {
      if (searchWord.length >= 1 && value) {
        outPut = value.filter((el: any) => {
          if (el[keyValue]) {
            let elementValue = el[keyValue].toString().toLowerCase();
            if (elementValue.search(searchWord.toLowerCase()) > -1) {
              return el;
            }
          }
        });
        return outPut;
      }
      else
        return outPut;
    }
    else
      // return outPut;
      return value;

  }



}