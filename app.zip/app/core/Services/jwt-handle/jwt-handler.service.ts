import { Injectable } from '@angular/core';
import jwt_decode from 'jwt-decode';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class JwtHandlerService {
  private userToken : string ='';
  userDetails$: BehaviorSubject<any> = new BehaviorSubject(this.userToken);

  
  /*
   * @desc to decode token
   * @author Nilena Alexander
   * @param userToken
   */
  decodeToken(token: string) {
    const decoded = jwt_decode(token);
    this.userDetails$.next(decoded);
  }

  /*
   * @desc to set token to localstorage
   * @author Nilena Alexander
   * @param userToken
   */
  public  setUserTtoken(token: any) {
    this.userToken = token;
    localStorage.setItem('token',  this.userToken);
   this.decodeToken(this.userToken );
  }

 
  /*
   * @desc to get token to localstorage
   * @author Nilena Alexander
   */
  public  getUserToken() {
    if (localStorage.getItem('token')) return this.decodeToken (this.userToken);
  }

  /*
   * @desc to select a courier agent
   * @author Nilena Alexander
   * @param array contains list of agent
   */
  public getUserTokenChanges(): Observable<any>{
    return this.userDetails$.asObservable();
  }
}
