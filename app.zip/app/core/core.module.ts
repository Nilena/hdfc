import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { throwIfAlreadyLoaded } from './Guards/module-import.guard';
import { HeaderComponent } from './Components/header/header.component';
import { MenubarComponent } from './Components/menubar/menubar.component';
import { CommonLoaderComponent } from './Components/common-loader/common-loader.component';
import { AppRoutingModule } from '../app-routing.module';



@NgModule({
  declarations: [
    HeaderComponent,
    MenubarComponent,
    CommonLoaderComponent,
  ],
  imports: [
    CommonModule,
    AppRoutingModule
  ],
  exports:[
    HeaderComponent,
    MenubarComponent,
    CommonLoaderComponent
  ]
})
export class CoreModule { 
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    throwIfAlreadyLoaded(parentModule, 'CoreModule');
  }
}
