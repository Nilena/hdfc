export const CONSTANTS= {
  alertClass : {
        success: 'alert--success',
        error: 'alert--error',
        warning: 'alert--warning',
        info: 'alert--info',
    },
  /* sample deatls form lables 
    used in new-case.component
   **/
      sampleDetailsLabel: [
        'Sample ID', 
        'Sample Received',
        'Case Role', 
        'Sample Type', 
        'Name', 
        'A.K.A.', 
        'Deceased',
        'Gender', 
        'Date of Birth', 
        'SSN', 
        'Race/Age for Child', 
        'Collection Date', 
        'Collection ID', 
        'Collection Site', 
        'Collector Name', 
        'EXT. Party Identifier', 
        'Tracking#'
      ],

      testPartys: [ 
        {id: 1, role: 'Mother'}, 
        {id: 2, role: 'Child'}, 
        {id: 3, role: 'Alleged Father'}
      ],
      deceased: [
        {id: '0', value: 'No'}, 
        {id: '1', value: 'Yes'}
      ],
      gender: [
        {id: 'm', value: 'Male'}, 
        {id: 'f', value: 'Female'}
      ],
      channelTypeList: [
        { 
          id : '1',
          type: 'chain'
         },
        { 
          id :'0',
          type: 'non-chain' 
        },
      ],

     docCategory:{
       internal:'internal',
       external:'external',
       all:'all'
     }
    
}