import { environment } from "src/environments/environment";

export const getApiUrl = (relativeUrl: string): string => {
    return `${environment.apiDomain}/${relativeUrl}`;
}

export const apiList = {
    package:{
        getChannels :  'api/v1/channels',
        getCourier:'api/v1/couriers',
        getTracking : 'api/v1/tracking',
        packageListing: 'api/v1/packages',
        getUsersdata: 'api/v1/users',
        getComments: 'api/v1/trackings/comment',
        getEmailList : 'api/v1/channel',
        getReceipt:'api/v1/receipt',
        postNotifications : 'api/v1/trackings/notification'
    },
    case:{
        getTestPartyRoles: 'api/v1/testPartyRoles',
        languages :'api/v1/languages',
        states : 'api/v1/states',
        agencies : 'api/v1/agencies',
        testTypes : 'api/v1/testTypes',
        additionalTest : 'api/v1/additionalTests',
        tatMasters : 'api/v1/tatMasters',
        subcategory : 'api/v1/testTypes/subCategory',
        cases : 'api/v1/cases',
        collectionSites:'api/v1/collectionSites',
        sampleTypes: 'api/v1/sampleTypes',
        testPartyRace: 'api/v1/testPartyRaces',
        collectorAgents: 'api/v1/collectionAgents',
        uploadDoc:'api/v1/caseDoc',
        documentTypes: 'api/v1/documentTypes',
        comments:'api/v1/caseDoc/comments'
    }

}

