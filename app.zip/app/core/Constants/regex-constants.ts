export const REGCONSTANTS = {
    numberWithDecimal: /[^0-9^.]*/g,
    numberValidation: /[^0-9]*/g,
    emailRegExp: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/,
    nameValidation : '^[a-zA-Z ]*$',
    userName : "^[a-zA-Z0-9._@]+$",
} 