import { Injectable } from '@angular/core';
import {  CanDeactivate } from '@angular/router';
import { ScanNewComponent } from 'src/app/package/Components/scan-new/scan-new.component';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';

@Injectable({
  providedIn: 'root'
})

export class UnsavedChangesGuard implements CanDeactivate<ScanNewComponent> {
  constructor(private alertandtoaster: AlertandtoasterService) {
  }
  canDeactivate(
    component: ScanNewComponent){
      if(component.scanedItems.length){
          return this.alertandtoaster.alert.confirm({
          text: 'Are you sure you want to leave this Page?',
          type: 'warning-icon',
          hideCancelButton: true,
          cancelText : 'Cancel',
          okText: 'Leave',
          title: 'Confirmation'
        }).then(res => {
          if (res) {
           return true;
          }
          else{
            return false;
          }
        })
      }
    return true;
  }
  
}
