export interface FileData {
  lastModified?: number;
  lastModifiedDate?: object;
  name?: string;
  size?: number;
  type?: string;
  webkitRelativePath?: string;
}
export interface Channels {
  allowNotification?: boolean;
  channelAbbr?: string;
  channelId?: number;
  channelName?: string;
  cssClassName?: string;
  defaultEmail: string;
  channelType?: string;
}
export interface TestType {
  testTypeId: number;
  testType: string;
  testTypeDesc: string;
  noOfParties: number;
  raceCriteria: number;
  isEvaluate: boolean;
  sampleGroup: string;
  isNonHuman: boolean;
  labName: string;
}
export interface AdditionalTest {
  additionalTest: string;
  id: number;
}
export interface SampleType {
  id: number;
  sampleType: string;
  sampleTypeDesc: string;
}
export interface Languages {
  langId: number;
  langCode: string;
  langName: string;
}
export interface TestPartAPIData {
  testPartyRoles: TestedPartyRoles;
  totalElements: number;
  totalPages: number;
}
export interface TestedPartyRoles {
  acronym: string;
  role: string;
  roleId: number;
}
export interface States {
  stateId: number;
  stateCode: number;
  stateName: string;
}
export interface Agencies {
  agencyId: number;
  agencyName: string;
  agencyCode: number;
  agencyZipCode: string;
  address: string;
  serviceType?: string;
}
export interface TatType {
  id?: number
  tatTime: number;
  tatTimeInTerms: string;
  cutOffTime: null;
  tatTimeDisplay?: number | string;
  agency?: Agency
}
export interface Agency {
  address: string
  agencyCode: number
  agencyId: number
  agencyName: string
  agencyZipCode: string
}

export interface TestType {
  testTypeId: number;
  testType: string;
  testTypeDesc: string;
  noOfParties: number;
  raceCriteria: number;
  isEvaluate: boolean;
  sampleGroup: string;
  isNonHuman: boolean;
  labName: string;
}
export interface TestSubCategories {
  subCategoryId: number;
  subCategory: string;
}

export interface CollectionSites {
  id: number;
  siteName: string;
  siteCode: string;
  zipCode: string;
  siteAddress: string;
}

export interface AdditionalTest {
  additionalTest: string;
  id: number;
}
export interface QuickSearchData {
  caseNo: number;
  referenceNo: string;
  testedParty: string;
  dob: string | undefined;
}
export interface UserDetails {
  userId: number;
  userFullName: string;
  userName: string;
}
export interface ScanNewForm {
  channel: string;
  state: string;
  Account: string;
  authentication: number;
  docketNo: number;
  agencycaseno: number;
  caseDefinition: string;
  caseDefinition1: string;
  additionalTesting: string;
  Turnaround: string;
  Type: string;
  Private: boolean;
  courtOrder: boolean;
  dueDate: number;
  emboss: boolean;
  Language: string;
  Affidavit: boolean;
}
export interface CaseDetails {
  account?: string;
  additionalTesting?: string;
  affidavit?: number;
  agencyCaseNumber?: string;
  accountId?:number;
  allReceivedDate?: string;
  authenticationCode?: string;
  isPrivate?: number;
  caseId?: number;
  caseReportLanguage?: [];
  chain?: number;
  courtOrder?: number;
  createdBy?: string;
  createdOn?: string;
  directorSoDate?: string;
  docketNo?: string;
  dueDate?: string;
  emboss?: number;
  reportSendOn?: string;
  samples?: SampleDetails;
  state?: string;
  subCategory?: string;
  tatTime?: number;
  tatTimeInTerms?: string;
  testType?: string;
  caseStatus?: string;
  cssClassName?: string;
  channelName?: string;
  accessionedOn?: string;
  accessionedBy?: string;
}
export interface SampleDetails {
  sampleId: string;
  sampleReceivedOn: string;
  caseRole: string;
  sampleType: string;
  fullName: string;
  aka: string;
  deceased: number;
  gender: string;
  dob: Date;
  ssn: string;
  race: string;
  collectionDate: string;
  collectionId: string;
  collectionSite: string;
  collectorName: string;
  trackingNo: string;
  name?: string;
  extPartyIdentifier?: string;
  testPartyName?: string;
  tackingNo?: number;
  courtOrder?: number;
  firstName?: string;
  middleName?: string;
  lastName?: string;
}
export interface CollectionSite {
  id: number;
  siteAddress: string;
  siteCode: string;
  siteName: string;
  zipCode: number;
}
export interface CaseSamples {
  collectionSite: string;
  testPartyDOB: Date;
  testPartyName: string;
  testPartyRole: string;
  testPartySsn: string;
}
export interface PaginationDetails {
  pageNo: number;
  pageSize?: number;
  totalPages: number;
}
export interface CollectionAgent {
  agentContact: string;
  agentLastName: string;
  agentName: string;
  id: number;
  serviceType: string;
}


export interface AdvanceSearchData {

  channelId: number
  stateId: number;
  agencyId: number;
  testTypeId: number;
  testTypeSubCategoryId: number;
  additionalTestId: number;
  tatId: number;
  languageId: number;
  authenticationCode: string;
  agencyCaseNo: string;
  docketNo: string;
  chain: number;
  emboss: number;
  affidavit: number;
  billingType: string;
  courtOrder: number;

  caseCreatedStartDate: string;
  caseCreatedEndDate: string;
  caseCreatedBy: number;
  sampleReceivedStartDate: string;
  sampleReceivedEndDate: string;
  dueStartDate: string;
  dueEndDate: string;
  directorSoStartDate: string;
  directorSoEndDate: string;
  qcStartDate: string;
  qcEndDate: string;
  qcBy: number;
  auditedStartDate: string;
  auditedEndDate: string
  auditedBy: number;
  closedStartDate: string;
  closedEndDate: string;
  closedBy: number;
  sampleId: number;
  sampleTypeId: number;
  testPartyName: string;
  deceased: number;
  gender: string;
  ssn: string;
  race: string;
  collectionStartDate: string;
  collectionEndDate: string;
  collectionAgentId: number;
  collectionSiteId: number;
  extPartyIdentifier: number;
}
export interface TestPartyRaces {
  context: string;
  initial: string;
  race: string;
  raceId: number
  sortOrder: string | number
}

export interface DocUploadObj {
  documentTypes: DocumentTypes[];
  caseId?: number;
  testPartyRoles?: [];
  category?: string,
  comment?: string
}
export interface TestPartyRoles {
  testPartyRoleId: number
}
export interface DocumentTypes {
  documentTypeId?: number
  id?: number
  documentType?: string
}
export interface DocumentList {
  docUrl: string
  documentFileName: string,
  documentId: number,
  documentTypes: [],
  testPartyRoles: [],
  uploadDoneBy: string,
  uploadDoneOn: Date,
  test1st?: string
  doc1st?: string
  commentSectionOpen?: boolean
  comments?: Comments[]
  category?:string
  documentFileSize?:string
  caseId?:string

}
export interface Comments {
  comment: string,
  addedBy: string,
  addedOn: Date,
  updatedBy: string,
  updatedOn: Date
}