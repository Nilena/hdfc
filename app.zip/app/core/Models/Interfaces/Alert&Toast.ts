export type AlertType = 'success' | 'error' | 'warning' | 'info' | 'warning-icon';

export interface AlertInfo {
    type: AlertType;
    title: string;
    text: string;
    okText?: string;
    cancelText?: string;
    hideCancelButton?: boolean;
    isTitleCash?: boolean;
    hideOkButton?: boolean;
    addditionalButton?: {
      buttonText : string,
      actionFunction : VoidFunction;
    };
  }
  export interface AlertInfoTrigger extends AlertInfo {
    resolve: Function;
  }
export interface Toast {
    title:string,
    type :string,
    message:string
}
export interface Alert {
    title:string,
    message?:string,
    btnCancel?:string,
    btnCancelShow?:boolean,
    btnSuccess?:string,
    btnSuccessShow?:boolean,
    closeBtn?:boolean
}