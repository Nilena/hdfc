export class PackageListigRequest {
    pageSize: number
    pageNo: number
    trckNo: string
    cur: number
    chnl: number
    usr: number
    frmDt: string
    toDt: string
    sort?:string

    constructor(pageSize: number, pageNo: number, trckNo: string,
        cur: number, chnl: number, usr: number, frmDt: string, toDt: string, sort?:string) {
            this.pageSize = pageSize
            this.pageNo = pageNo
            this.trckNo = trckNo
            this.cur = cur
            this.chnl = chnl
            this.usr = usr
            this.frmDt = frmDt
            this.toDt = toDt
            this.sort = sort
        }


}
